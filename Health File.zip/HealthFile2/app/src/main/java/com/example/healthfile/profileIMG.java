package com.example.healthfile;

public class profileIMG {
    private String pImgUrl;

        public profileIMG(){

        }
        public profileIMG(String ImgUrl){
            this.pImgUrl=ImgUrl;

        }

        public String getpImgUrl() {
            return pImgUrl;
        }

        public void setpImgUrl(String ImgUrl) {
            pImgUrl = ImgUrl;
        }

}

